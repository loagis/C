#include <stdio.h>
#include <time.h>

struct Messung {
    int spannung;
    float stromstaerke;
    unsigned short druck;
    struct tm zeit;
};


void
ausgabe(struct Messung m) {

    printf("%d:%d.%d %d V, %.2f A, %u bar\n",
           m.zeit.tm_hour, m.zeit.tm_min, m.zeit.tm_sec,
           m.spannung, m.stromstaerke, m.druck);

} /* ausgabe */


int 
main(int argc, 
     char **argv) {

    struct Messung m;
    time_t t;


    time(&t);
    m.zeit = *localtime(&t);

    printf("Spannung [V]: ");
    scanf("%d", &m.spannung);

    printf("Strom [A]: ");
    scanf("%f", &m.stromstaerke);

    printf("Druck [bar]: ");
    scanf("%hu", &m.druck);

    ausgabe(m);

    return 0;

} /* main*/
