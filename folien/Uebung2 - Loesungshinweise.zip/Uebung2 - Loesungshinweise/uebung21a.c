#include <stdio.h>

int 
main(int argc,
     char **argv) {


    printf("size of char: %lu\n", sizeof(char));
    printf("size of short int: %lu\n", sizeof(short int));
    printf("size of int: %lu\n", sizeof(int));
    printf("size of long int: %lu\n", sizeof(long int));
    printf("size of float: %lu\n", sizeof(float));
    printf("size of double: %lu\n", sizeof(double));

} /* main */
