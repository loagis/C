#include <stdio.h>


struct Bruch {
    int zaehler;
    int nenner;
};

typedef struct Bruch Rational;


/* Euklid */
/* https://en.wikipedia.org/wiki/Euclidean_algorithm */
int
ggT(int a, int b) {

    while (b != 0 ) {
        int r = a % b;
        a = b;
        b = r;
    }

    return a;

} /* ggT */


/* We already know ggT() */
/* https://en.wikipedia.org/wiki/Least_common_multiple */
int
kgV(int a, int b){

    return a*b/ggT(a, b);

} /* kgV */


Rational
kuerze(Rational r) {
    Rational tmp;

    int ggt = ggT(r.zaehler, r.nenner);

    tmp.zaehler = r.zaehler / ggt;
    tmp.nenner = r.nenner / ggt;

    return tmp;

} /* kuerze */


Rational
addiere(Rational a, Rational b) {
    Rational tmp;

    int kgv = kgV(a.nenner, b.nenner);

    tmp.zaehler = (kgv/a.nenner)*a.zaehler + kgv/(b.nenner)*b.zaehler;
    tmp.nenner = kgv;

    return kuerze(tmp);

} /* addiere */


Rational
subtrahiere(Rational a, Rational b) {
    Rational tmp;

    int kgv = kgV(a.nenner, b.nenner);

    tmp.zaehler = (kgv/a.nenner)*a.zaehler - kgv/(b.nenner)*b.zaehler;
    tmp.nenner = kgv;

    return kuerze(tmp);

} /* subtrahiere */


Rational
multipliziere(Rational a, Rational b) {
    Rational tmp;

    tmp.zaehler = a.zaehler * b.zaehler;
    tmp.nenner = a.nenner * b.nenner;

    return kuerze(tmp);

} /* multipliziere */


Rational
dividiere(Rational a, Rational b) {
    Rational tmp;

    tmp.zaehler = a.zaehler * b.nenner;
    tmp.nenner = a.nenner * b.zaehler;

    return kuerze(tmp);

} /* dividiere */


float
toFloat(Rational r) {

    return (float)r.zaehler / r.nenner;

} /* toFloat */


void
ausgabe(Rational r) {

    printf("%d / %d\n", r.zaehler, r.nenner);

} /* ausgabe */


int 
main(int argc,
     char **argv) {

    Rational r1 = {3, 6}, r2 = {1, 2};

    /* test cases? */
    printf("toFloat(%d/%d) = %f\n", r1.zaehler, r1.nenner, toFloat(r1));

    printf("kuerze(%d/%d) = ", r1.zaehler, r1.nenner);
    ausgabe(kuerze(r1));

    printf("addiere(%d/%d, %d/%d) = ", r1.zaehler, r1.nenner,
                                       r2.zaehler, r2.nenner);
    ausgabe(addiere(r1, r2));

    printf("subtrahiere(%d/%d, %d/%d) = ", r1.zaehler, r1.nenner,
                                       r2.zaehler, r2.nenner);
    ausgabe(subtrahiere(r1, r2));

    printf("multipliziere(%d/%d, %d/%d) = ", r1.zaehler, r1.nenner,
                                             r2.zaehler, r2.nenner);
    ausgabe(multipliziere(r1, r2));

    printf("dividiere(%d/%d, %d/%d) = ", r1.zaehler, r1.nenner,
                                         r2.zaehler, r2.nenner);
    ausgabe(dividiere(r1, r2));

    return 0;

} /* main */
