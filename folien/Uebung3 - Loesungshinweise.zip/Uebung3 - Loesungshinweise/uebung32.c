#include <math.h>
#include <stdio.h>


/*
** Keep in mind that comparing floating point numbers
** as it is done here usually does not lead to the 
** expected answer.
*/


double
f(double x) {

    return pow(x, 3) - 2*pow(x, 2) - x + 2;

} /* f */


double
g(double x) {

    return (x == 0)? 1.0 : sin(x)/x;

} /* g */


/* https://en.wikipedia.org/wiki/Integral */
double
_integral(double (*func)(double), double a, double b, double incr){

    double sum = 0;

    while (a+incr<=b) {

        double u = func(a);
        double o = func(a+incr);
        sum += (incr)*(u+o)/2.0;
        a += incr;

    } 

    /* Remainder of last strip (if there's any) */
    if (a<b) {
        double u = func(a);
        double o = func(b);
        sum += (incr)*(u+o)/2.0;
    }

    return sum;

} /* _integral */


double
integral(double a, double b, double incr) {

    return _integral(&f, a, b, incr);

} /* integral */


int 
main(int argc,
     char **argv) {

    printf("f(x) = %f\n", _integral(&f, -1.0, 2.0, 0.01));
    printf("g(x) = %f\n", _integral(&g, -1000.0, 1000.0, 0.1));

    return 0;

} /* main */
