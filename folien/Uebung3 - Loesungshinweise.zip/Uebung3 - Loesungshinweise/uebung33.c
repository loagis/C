#include <stdio.h>
#include <math.h>

#define EPSILON 0.0001


double
_hsqrt(int a, float xn, float s) {

    if (fabs(xn - s) < EPSILON)
        return xn;
    return _hsqrt(a, 0.5 * (xn + a/xn), xn);

} /* _hsqrt */


double
hsqrt(int a) {

    if (a<0)
        return -1;

    return _hsqrt(a, (a+1.)/2., 0);

} /* hsqrt */


int 
main(int argc,
     char **argv) {

    /* test cases? */
    printf("hsqrt(16): %.3f\n", hsqrt(16));
    printf("hsqrt(3): %.3f\n", hsqrt(3));
    printf("hsqrt(0): %.3f\n", hsqrt(0));
    printf("hsqrt(-3): %.3f\n", hsqrt(-3));

    return 0;

} /* main */
