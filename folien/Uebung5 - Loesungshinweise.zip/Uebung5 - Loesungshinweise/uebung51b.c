#include <stdio.h>
#include <math.h>

/* Approximation of Euler's number */
#define E 2.718281828

/* Generate a factor */
#define F(d) (1e##d##f)

/* Multiply a number f with factor d */
#define M(f, d) (f*F(d))

/* Round a number f to d digits */
#define Round(f, d) ((M(f, d) > (floor(M(f, d))+0.5f)           \
                      ? ceil(M(f, d)) : floor(M(f, d))) / F(d))

int
main (int argc,
      char **argv) {

    printf("Euler's number rounded to four digits: %f\n", Round(E, 4));

} /* main */
