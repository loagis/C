#ifndef INCLUDED_OPERATION_H
#define INCLUDED_OPERATION_H

float add(float, float);
float subtract(float, float);
float multiply(float, float);
float divide(float, float);

#endif /* INCLUDED_OPERATION_H */
