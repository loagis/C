#include <stdio.h>
#include <math.h>


/* Approximation of Euler's number */
#define E 2.718281828

#define FUNKTION(X) (powf(E, (X)) + 5*(X) + 3)

int
main (int argc,
      char **argv) {

    unsigned i;

    for (i=0; i<10; ++i)
        printf("f(%d) = %f\n", i, FUNKTION(i));

} /* main */
