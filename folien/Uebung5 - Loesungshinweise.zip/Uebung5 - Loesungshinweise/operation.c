#include <math.h>
#include "operation.h"

float
add(float op1, float op2) {

    return op1+op2;

} /* add */


float
subtract(float op1, float op2) {

    return op1-op2;

} /* subtract */


float
multiply(float op1, float op2) {

    return op1*op2;

} /* multiply */


float
divide(float op1, float op2) {

    if (0 != op2)
        return op1/op2;
    else
        return NAN;

} /* divide */
