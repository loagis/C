#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FREE(p) if (p) {free(p); p = NULL;}

char*
toBinaryString(int n) {
    unsigned int bits = 8 * sizeof(n);
    unsigned int i, j;
    unsigned int firstone = 0;
    char *tmp;


    /* Avoid endless loop */
    if (n == 0) {
        tmp = malloc(2*sizeof(char));
        if (!tmp) {
            return NULL;
        }

        tmp[0] = '0'; tmp[1] = 0;
        return tmp;
    }

    /* First we cut off the leading zeroes
       2^31 <> 0x80000000 */
    while ((n & 0x80000000) == 0) {
        firstone++;
        n = n<<1;
    }

    /* Get buffer for the remaining digits */
    tmp = malloc((bits - firstone + 1) * sizeof(char));
    if (!tmp) {
        return NULL;
    }
    memset(tmp, 0, bits - firstone + 1);

    for (i=firstone, j=bits-firstone-1; i<bits; i++, j--) {
        tmp[j] = (n & (1u<<i))?'1':'0';
    }

    return tmp;

} /* toBinaryString */


/*
** We use a preprocessor macro here to ease the
** repetitive work of error handling. On the downside,
** the macro's parameter num isn't type safe.
*/
#define EXE(num)                                               \
    {                                                          \
    char *tmp = NULL;                                          \
    tmp = toBinaryString(num);                                 \
    if (tmp) {                                                 \
        printf("toBinaryString(%d)= '%s'\n", num, tmp);        \
        FREE(tmp);                                             \
    } else {                                                   \
        fprintf(stderr, "Bummer, couldn't allocate memory\n"); \
    }                                                          \
    }

int 
main(int argc,
     char **argv) {

    /* test cases? */
    EXE(0)
    EXE(10)
    EXE(0xffff)
    EXE(0xffffffff)

    return 0;

} /* main */
