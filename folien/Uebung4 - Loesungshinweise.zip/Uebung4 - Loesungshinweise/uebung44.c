#include <stdio.h>
#include <string.h>


/*
** The idea is that the characters a to z and the numbers
** 0 to 9 are ordered and every symbol has a number assigned
** to itself (see ascii(7)). With that in mind, you can shift
** the range of the assigned numbers, so that it matches the
** indices of the array used for counting.
**
** E.g.: 'a' has a certain number n (maybe n=97) assigned, 'b' then
** has n+1 (or 98) assigned. To count the occurences of character 'a'
** at array index 0 and character 'b' at array index 1 etc., you
** need to map 97 to 0, 98 to 1 etc.: just think of your characters
** as integers and subtract 'a' from them.
*/
void
countChars(unsigned int *cnt, char *text) {

    while (*text) {
        int c = *text++;

        if (c>='a' && c<='z')
            cnt[c-'a']++;
        else if (c>='0' && c<='9') {
            cnt[26+c-'0']++;}
        else
            cnt[36]++; 
    }

} /* countChars */


int 
main(int argc,
     char **argv) {

    unsigned int cnt[37] = {0};
    int i;

    for (i=1; i<argc; i++)
        countChars(&cnt[0], argv[i]);

    for(i=0; i<26; i++)
        printf("%c: %d\n", i+'a', cnt[i]);

    for(i=26; i<36; i++)
        printf("%c: %d\n", i+'0'-26, cnt[i]);

    printf("Unbekannt: %d\n", cnt[36]);

    return 0;

} /* main */
