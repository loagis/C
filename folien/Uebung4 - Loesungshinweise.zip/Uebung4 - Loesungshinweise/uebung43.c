#include <stdio.h>

#define L  3

/* https://en.wikipedia.org/wiki/Matrix_multiplication */

/*
** This works, but is for the sake of illustration only.
** Because of the function's signature it's not a solution
** to the pset.
*/
void
multiply1(int a[L][L], int b[L][L], int c[L][L]) {

    int row, col, k;

    for (row=0; row<L; row++) {
        for (col=0; col<L; col++) {

            for (k=0; k<L; k++) {
                c[row][col] += a[row][k] * b[k][col];
            } /* for k */

        } /* for col */
    } /* for row */

} /* multiply1 */



/*
** Keep in mind, that in C arrays usually are stored
** in row first order.
*/
void
multiply(int *a, int *b, int *c, int n) {

    int row, col, k;

    for (row=0; row<n; row++) {
        for (col=0; col<n; col++) {

            for (k=0; k<n; k++) {
                *(c + row*n+col) += *(a + row*n+k) * *(b + k*n+col);
            } /* for k */

        } /* for col */
    } /* for row */

} /* multiply */


int 
main(int argc,
     char **argv) {

    int row, col;

    int a[L][L] = {{1, 2,  3}, {4, 1, 0}, {-1, 18, 7}};
    int b[L][L] = {{1, 0, -1}, {2 ,1, 0}, { 5,  0, 1}};
    int c[L][L] = {{0}, {0}, {0}};

    multiply1(a, b, c);
    printf("multiply1:\n");
    for (row=0; row<L; row++) {
        for (col=0; col<L; col++) {
            printf("%d\t", c[row][col]);
        }
        printf("\n");
    }


    int d[L*L] = {1, 2,  3, 4, 1, 0, -1, 18, 7};
    int e[L*L] = {1, 0, -1, 2 ,1, 0,  5,  0, 1};
    int f[L*L] = {0};
    multiply(d, e, f, L);
    printf("\nmultiply:\n");
    for (row=0; row<L; row++) {
        for (col=0; col<L; col++) {
            printf("%d\t", f[row*L+col]);
       } 
        printf("\n");
    }

    return 0;

} /* main */
