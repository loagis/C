#include <stdio.h>
#include <stdlib.h>

#define FREE(p) if (p) {free(p); p = NULL;}

#define LEN 10

#if 0
/*
** Here we create the array a in 
** createArrayOnFunctionsStack's stack frame. When
** we return from the function, its stack frame is
** destroyed and so is the array. So this is not a
** solution.
*/
int *
createArrayOnFunctionsStack() {

    int i;
    int a[LEN];

    for (i=0; i<LEN; i++)
        a[i] = i+1;

    return a;

} /* createArrayOnFunctionsStack */
#endif


/*
** Here we use an array (given by the formal input
** parameter int *a) that is allocate in main's
** stack frame. The array is valid as long as 
** main's stack frame is valid. Technically, this 
** can be a solution, but if you stick to the words
** of the pset 'Erstellen Sie eine Funktion, die ein
** int[10] erstellt', it is not.
*/
void
createArrayOnMainsStack(int *a) {

    int i;
    for (i=0; i<LEN; i++)
        a[i] = i+1;

} /* createArrayOnMainsStack */


/*
** In this variant we create the array on the heap, 
** which is a nice solution.
*/
int *
createArrayOnHeap() {

    int i;

    int *a = malloc(LEN*sizeof(int));
    if (!a) {
        return NULL;
    }

    for (i=0; i<LEN; i++)
        a[i] = i+1;

    return a;

} /* createArrayOnHeap */


/*
** One last try. We create the array as a local
** static variable. Do you see the possible problem
** with that approach? What happens if you need two 
** arrays? Calling createArrayInDataSegment() twice?
** What, if you then change one array?
*/
int *
createArrayInDataSegment() {

    static int a[LEN];
    int i;

    for (i=0; i<LEN; i++)
        a[i] = i+1;

    return a;

} /* createArrayInDataSegment */


int 
main(int argc,
     char **argv) {

    int i;
    int *a;
    int b[LEN];

    printf("Array on heap:\n");
    a = createArrayOnHeap();
    if (a) {
        for (i=0; i<LEN; i++) {
            printf("a[%d] = %d\n", i, a[i]);
        }
        FREE(a);
    } else {
        fprintf(stderr, "Bummer, couldn't allocate array\n");
    }

    printf("Array on main's stack:\n");
    createArrayOnMainsStack(b);
    for (i=0; i<LEN; i++) {
        printf("b[%d] = %d\n", i, b[i]);
    }

    printf("Array data segment:\n");
    a = createArrayInDataSegment();
    for (i=0; i<LEN; i++) {
        printf("b[%d] = %d\n", i, a[i]);
    }

    /* This is not a solution, so it's commented */
#if 0
    printf("Array on function's stack:\n");
    a = createArrayOnFunctionsStack();
    for (i=0; i<LEN; i++) {
        printf("a[%d] = %d\n", i, a[i]);
    }
#endif

    return 0;

} /* main */
